'use client'

import { useEffect, useRef, useState } from 'react'
import useSWR from 'swr'
import { Check, Heart, LogOut, SendHorizontal, Settings } from 'lucide-react'
import { cn } from '@/lib/utils'
import { CallButton } from '@/components/call-button'
import { SettingsPanel } from '@/components/settings-panel'

const FONT_SIZES = [13, 15, 17, 20, 24, 28]
const DEFAULT_FONT_INDEX = 1
const FONT_STORAGE_KEY = 'calc_fs'

function readFontIndex() {
  if (typeof window === 'undefined') return DEFAULT_FONT_INDEX
  const stored = Number(window.localStorage.getItem(FONT_STORAGE_KEY))
  return Number.isInteger(stored) && stored >= 0 && stored < FONT_SIZES.length ? stored : DEFAULT_FONT_INDEX
}

type Message = { id: number; mine: boolean; body: string; createdAt: string }
type ChatData = { me: 'me' | 'her'; myName: string; partnerName: string; messages: Message[] }

class UnauthorizedError extends Error {}

const fetcher = async (url: string) => {
  const res = await fetch(url, { cache: 'no-store' })
  if (res.status === 401) throw new UnauthorizedError()
  if (!res.ok) throw new Error('failed')
  return res.json()
}

const timeFmt = new Intl.DateTimeFormat('ar', { hour: '2-digit', minute: '2-digit' })

export function ChatScreen({ onLock }: { onLock: () => void }) {
  const { data, error, mutate } = useSWR<ChatData>('/api/messages', fetcher, {
    refreshInterval: 2500,
    revalidateOnFocus: false,
  })
  const [text, setText] = useState('')
  const [sending, setSending] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [fontIndex, setFontIndex] = useState(readFontIndex)
  const fontSize = FONT_SIZES[fontIndex]

  const changeFont = (delta: number) => {
    setFontIndex((i) => {
      const next = Math.min(FONT_SIZES.length - 1, Math.max(0, i + delta))
      window.localStorage.setItem(FONT_STORAGE_KEY, String(next))
      return next
    })
  }

  const bottomRef = useRef<HTMLDivElement>(null)
  const count = data?.messages.length ?? 0

  useEffect(() => {
    if (error instanceof UnauthorizedError) onLock()
  }, [error, onLock])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: 'end' })
  }, [count])

  const send = async (e: React.FormEvent) => {
    e.preventDefault()
    const body = text.trim()
    if (!body || sending) return
    setSending(true)
    setText('')
    const optimistic: Message = { id: -Date.now(), mine: true, body, createdAt: new Date().toISOString() }
    try {
      await mutate(
        async (current) => {
          await fetch('/api/messages', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ body }),
          })
          return current
        },
        {
          optimisticData: (current) =>
            current ? { ...current, messages: [...current.messages, optimistic] } : current!,
          revalidate: true,
        },
      )
    } finally {
      setSending(false)
    }
  }

  const wipe = async () => {
    if (!confirm('حذف جميع الرسائل نهائياً؟')) return
    await fetch('/api/messages', { method: 'DELETE' })
    setSettingsOpen(false)
    mutate()
  }

  return (
    <main className="flex h-dvh w-full flex-col bg-background pt-[env(safe-area-inset-top)]">
      <header className="flex shrink-0 items-center justify-between gap-2 border-b border-border bg-card px-3 py-2.5">
        <div className="flex min-w-0 items-center gap-2.5">
          <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-rose-500 text-white">
            <Heart className="size-4 fill-current" aria-hidden />
          </div>
          <h1 className="truncate text-sm font-bold text-card-foreground">{data?.partnerName ?? '...'}</h1>
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <CallButton onUnauthorized={onLock} />
          <button
            type="button"
            onClick={() => setSettingsOpen(true)}
            disabled={!data}
            aria-label="الإعدادات"
            className="flex size-9 items-center justify-center rounded-lg bg-secondary text-muted-foreground transition active:scale-95 disabled:opacity-40"
          >
            <Settings className="size-4" aria-hidden />
          </button>
          <button
            type="button"
            onClick={onLock}
            aria-label="خروج وقفل"
            className="flex h-9 items-center gap-1.5 rounded-lg bg-destructive px-3 text-xs font-bold text-white transition active:scale-95"
          >
            <LogOut className="size-4" aria-hidden />
            خروج
          </button>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto overscroll-contain px-3 py-4" aria-live="polite">
        {!data ? (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">...</div>
        ) : data.messages.length === 0 ? (
          <div className="flex h-full items-center justify-center text-sm text-muted-foreground">لا توجد رسائل بعد</div>
        ) : (
          <ul className="flex flex-col gap-2">
            {data.messages.map((m) => (
              <li key={m.id} className={cn('flex', m.mine ? 'justify-start' : 'justify-end')}>
                <div
                  className={cn(
                    'max-w-[80%] rounded-2xl px-3.5 py-2 leading-relaxed',
                    m.mine
                      ? 'rounded-br-md bg-primary text-primary-foreground'
                      : 'rounded-bl-md bg-secondary text-secondary-foreground',
                    m.id < 0 && 'opacity-60',
                  )}
                >
                  <p className="whitespace-pre-wrap break-words" style={{ fontSize }}>
                    {m.body}
                  </p>
                  <div className="mt-0.5 flex items-center justify-end gap-1 text-[10px] opacity-75">
                    <time dateTime={m.createdAt}>
                      {timeFmt.format(new Date(m.createdAt))}
                    </time>
                    {m.mine && (
                      <span className="inline-flex items-center">
                        <Check className="size-3 text-primary-foreground/80 inline-block" aria-hidden="true" />
                      </span>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
        <div ref={bottomRef} />
      </div>

      <form
        onSubmit={send}
        className="flex shrink-0 items-center gap-2 border-t border-border bg-card p-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))]"
      >
        <label htmlFor="chat-input" className="sr-only">
          اكتب رسالة
        </label>
        <input
          id="chat-input"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="اكتب رسالة..."
          autoComplete="off"
          maxLength={2000}
          className="min-w-0 flex-1 rounded-xl border border-border bg-background px-3.5 py-3 text-base text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
        />
        <button
          type="submit"
          disabled={!text.trim()}
          aria-label="إرسال"
          className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground transition active:scale-95 disabled:opacity-50"
        >
          <SendHorizontal className="size-5 rotate-180" aria-hidden />
        </button>
      </form>

      {settingsOpen && data && (
        <SettingsPanel
          myName={data.myName}
          partnerName={data.partnerName}
          fontIndex={fontIndex}
          onFontChange={changeFont}
          maxFontIndexLength={FONT_SIZES.length}
          onClose={() => setSettingsOpen(false)}
          onSaved={() => mutate()}
          onWipe={wipe}
        />
      )}
    </main>
  )
}
