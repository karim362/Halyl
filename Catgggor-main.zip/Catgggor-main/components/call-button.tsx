'use client'

import { useState } from 'react'
import { Phone, PhoneCall } from 'lucide-react'
import { cn } from '@/lib/utils'

const FEEDBACK: Record<string, string> = {
  sent: 'تم إرسال التنبيه',
  cooldown: 'انتظر قليلاً قبل التنبيه مرة أخرى',
  no_devices: 'الطرف الآخر لم يفعّل الإشعارات بعد',
  error: 'تعذر الإرسال',
}

export function CallButton({ onUnauthorized }: { onUnauthorized: () => void }) {
  const [state, setState] = useState<'idle' | 'calling'>('idle')
  const [feedback, setFeedback] = useState<string | null>(null)

  const call = async () => {
    if (state === 'calling') return
    setState('calling')
    let result = 'error'
    try {
      const res = await fetch('/api/signal', { method: 'POST' })
      if (res.status === 401) return onUnauthorized()
      if (res.ok) result = (await res.json()).status ?? 'error'
    } catch {}
    setState('idle')
    setFeedback(FEEDBACK[result] ?? FEEDBACK.error)
    setTimeout(() => setFeedback(null), 2500)
  }

  return (
    <>
      <button
        type="button"
        onClick={call}
        disabled={state === 'calling'}
        aria-label="إرسال تنبيه للطرف الآخر"
        className={cn(
          'flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground transition active:scale-95 disabled:opacity-60',
          state === 'calling' && 'animate-pulse',
        )}
      >
        {state === 'calling' ? <PhoneCall className="size-4" aria-hidden /> : <Phone className="size-4" aria-hidden />}
      </button>
      {feedback && (
        <div
          role="status"
          className="fixed inset-x-0 top-[calc(env(safe-area-inset-top)+4rem)] z-40 mx-auto w-fit max-w-[90vw] rounded-full bg-foreground px-4 py-2 text-sm font-bold text-background shadow-lg"
        >
          {feedback}
        </div>
      )}
    </>
  )
}
