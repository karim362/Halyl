'use client'

import { useState } from 'react'
import { Delete } from 'lucide-react'
import { cn } from '@/lib/utils'
import { SECRET_EXPRESSION, evaluate, formatResult } from '@/lib/calc'

type Key = { label: React.ReactNode; value: string; kind: 'num' | 'op' | 'fn' | 'eq' | 'clear'; wide?: boolean; aria?: string }

const KEYS: Key[] = [
  { label: 'AC', value: 'clear', kind: 'clear' },
  { label: <Delete className="size-5" aria-hidden />, value: 'del', kind: 'fn', aria: 'حذف' },
  { label: '%', value: '%', kind: 'fn' },
  { label: '÷', value: '/', kind: 'op' },
  { label: '7', value: '7', kind: 'num' },
  { label: '8', value: '8', kind: 'num' },
  { label: '9', value: '9', kind: 'num' },
  { label: '×', value: '*', kind: 'op' },
  { label: '4', value: '4', kind: 'num' },
  { label: '5', value: '5', kind: 'num' },
  { label: '6', value: '6', kind: 'num' },
  { label: '−', value: '-', kind: 'op' },
  { label: '1', value: '1', kind: 'num' },
  { label: '2', value: '2', kind: 'num' },
  { label: '3', value: '3', kind: 'num' },
  { label: '+', value: '+', kind: 'op' },
  { label: '0', value: '0', kind: 'num', wide: true },
  { label: '.', value: '.', kind: 'num' },
  { label: '=', value: '=', kind: 'eq' },
]

const pretty = (s: string) => s.replace(/\*/g, '×').replace(/\//g, '÷').replace(/-/g, '−')

export function Calculator({ onSecret }: { onSecret: () => void }) {
  const [input, setInput] = useState('')
  const [history, setHistory] = useState('')
  const [justEvaluated, setJustEvaluated] = useState(false)

  const press = (key: Key) => {
    if (key.value === 'clear') {
      setInput('')
      setHistory('')
      setJustEvaluated(false)
      return
    }
    if (key.value === 'del') {
      setInput((v) => v.slice(0, -1))
      setJustEvaluated(false)
      return
    }
    if (key.value === '=') {
      if (!input) return
      if (input === SECRET_EXPRESSION) {
        setInput('')
        setHistory('')
        onSecret()
        return
      }
      try {
        const result = formatResult(evaluate(input))
        setHistory(`${pretty(input)} =`)
        setInput(result === 'Error' ? '' : result)
        if (result === 'Error') setHistory('Error')
      } catch {
        setHistory('Error')
      }
      setJustEvaluated(true)
      return
    }
    setInput((v) => {
      if (justEvaluated && key.kind === 'num') return key.value
      return v.length >= 24 ? v : v + key.value
    })
    setJustEvaluated(false)
  }

  return (
    <main className="flex h-dvh w-full flex-col justify-between gap-4 bg-background p-4 pb-[max(1rem,env(safe-area-inset-bottom))] pt-[max(1rem,env(safe-area-inset-top))]">
      <header className="flex items-center justify-between px-1 text-[11px] text-muted-foreground">
        <span className="font-mono">SOLAR</span>
        <span className="font-bold tracking-widest">CASIO-FX</span>
      </header>

      <section
        aria-live="polite"
        className="my-auto rounded-2xl border border-border bg-card px-4 py-5 text-left shadow-inner"
        dir="ltr"
      >
        <div className="h-6 overflow-hidden text-right font-mono text-sm tracking-wider text-muted-foreground">
          {history}
        </div>
        <output className="mt-1 block truncate text-right font-mono text-4xl font-semibold text-foreground">
          {input ? pretty(input) : '0'}
        </output>
      </section>

      <div className="grid grid-cols-4 gap-2.5" dir="ltr">
        {KEYS.map((key) => (
          <button
            key={key.value}
            type="button"
            aria-label={key.aria}
            onClick={() => press(key)}
            className={cn(
              'flex h-16 touch-manipulation items-center justify-center rounded-2xl text-xl font-semibold shadow-sm transition active:scale-95 active:brightness-90',
              key.wide && 'col-span-2',
              key.kind === 'num' && 'bg-secondary text-secondary-foreground',
              key.kind === 'fn' && 'bg-muted text-muted-foreground',
              key.kind === 'op' && 'bg-accent text-accent-foreground',
              key.kind === 'eq' && 'bg-primary text-primary-foreground',
              key.kind === 'clear' && 'bg-destructive text-white',
            )}
          >
            {key.label}
          </button>
        ))}
      </div>
    </main>
  )
}
