'use client'

import { useState } from 'react'
import { Bell, BellRing, BellOff } from 'lucide-react'
import { cn } from '@/lib/utils'

type Status = 'idle' | 'working' | 'on' | 'blocked' | 'unsupported'

function urlBase64ToUint8Array(base64: string) {
  const padding = '='.repeat((4 - (base64.length % 4)) % 4)
  const raw = atob((base64 + padding).replace(/-/g, '+').replace(/_/g, '/'))
  return Uint8Array.from(raw, (c) => c.charCodeAt(0))
}

function initialStatus(): Status {
  if (typeof window === 'undefined') return 'idle'
  if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) return 'unsupported'
  if (Notification.permission === 'denied') return 'blocked'
  return 'idle'
}

export function NotifyButton() {
  const [status, setStatus] = useState<Status>(initialStatus)

  const enable = async () => {
    if (status === 'unsupported') {
      alert('المتصفح لا يدعم الإشعارات. على الآيفون: أضف الموقع للشاشة الرئيسية أولاً ثم افتحه من هناك.')
      return
    }
    if (status === 'blocked') {
      alert('الإشعارات محظورة من إعدادات المتصفح لهذا الموقع.')
      return
    }
    setStatus('working')
    try {
      const permission = await Notification.requestPermission()
      if (permission !== 'granted') {
        setStatus(permission === 'denied' ? 'blocked' : 'idle')
        return
      }
      const reg = await navigator.serviceWorker.register('/sw.js')
      await navigator.serviceWorker.ready
      const { publicKey } = await fetch('/api/push', { cache: 'no-store' }).then((r) => r.json())
      const existing = await reg.pushManager.getSubscription()
      const sub =
        existing ??
        (await reg.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: urlBase64ToUint8Array(publicKey),
        }))
      const res = await fetch('/api/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sub.toJSON()),
      })
      setStatus(res.ok ? 'on' : 'idle')
    } catch {
      setStatus('idle')
      alert('تعذر تفعيل الإشعارات، حاول مرة أخرى.')
    }
  }

  const Icon = status === 'on' ? BellRing : status === 'blocked' || status === 'unsupported' ? BellOff : Bell

  const label = status === 'on' ? 'الإشعارات مفعلة على هذا الجهاز' : 'تفعيل الإشعارات على هذا الجهاز'

  return (
    <button
      type="button"
      onClick={enable}
      disabled={status === 'working'}
      className={cn(
        'flex w-full items-center justify-center gap-2 rounded-xl bg-secondary py-3 text-sm font-bold transition active:scale-95 disabled:opacity-50',
        status === 'on' ? 'text-primary' : 'text-secondary-foreground',
      )}
    >
      <Icon className="size-4" aria-hidden />
      {label}
    </button>
  )
}
