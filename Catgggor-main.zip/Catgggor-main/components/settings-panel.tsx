'use client'

import { useEffect, useState } from 'react'
import { Trash2, X, AArrowDown, AArrowUp } from 'lucide-react'
import { NotifyButton } from '@/components/notify-button'

const ERRORS: Record<string, string> = {
  names_required: 'الأسماء مطلوبة',
  password_length: 'كلمة السر يجب أن تكون 4 أحرف على الأقل',
  wrong_password: 'كلمة السر الحالية غير صحيحة',
  passwords_same: 'لا يمكن أن تكون كلمة السر مثل كلمة سر الطرف الآخر',
}

type Props = {
  myName: string
  partnerName: string
  fontIndex: number
  onFontChange: (delta: number) => void
  maxFontIndexLength: number
  onClose: () => void
  onSaved: () => void
  onWipe: () => void
}

const inputClass =
  'w-full rounded-xl border border-border bg-background px-3.5 py-2.5 text-base text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none'

export function SettingsPanel({
  myName,
  partnerName,
  fontIndex,
  onFontChange,
  maxFontIndexLength,
  onClose,
  onSaved,
  onWipe,
}: Props) {
  const [form, setForm] = useState({ myName, partnerName, currentPassword: '', newPassword: '', confirm: '' })
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null)

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose])

  const update = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }))

  const save = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage(null)
    if (form.newPassword && form.newPassword !== form.confirm) {
      setMessage({ ok: false, text: 'تأكيد كلمة السر غير مطابق' })
      return
    }
    setSaving(true)
    try {
      const res = await fetch('/api/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          myName: form.myName,
          partnerName: form.partnerName,
          currentPassword: form.currentPassword,
          newPassword: form.newPassword,
        }),
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        setMessage({ ok: false, text: ERRORS[data.error] ?? 'حدث خطأ، حاول مرة أخرى' })
        return
      }
      setForm((f) => ({ ...f, currentPassword: '', newPassword: '', confirm: '' }))
      setMessage({ ok: true, text: 'تم الحفظ' })
      onSaved()
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 sm:items-center" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="settings-title"
        onClick={(e) => e.stopPropagation()}
        className="max-h-[90dvh] w-full max-w-sm overflow-y-auto rounded-t-3xl border border-border bg-card p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:rounded-3xl"
      >
        <div className="mb-4 flex items-center justify-between">
          <h2 id="settings-title" className="text-base font-bold text-card-foreground">
            الإعدادات
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="إغلاق"
            className="flex size-9 items-center justify-center rounded-lg text-muted-foreground transition active:scale-95"
          >
            <X className="size-5" aria-hidden />
          </button>
        </div>

        <form onSubmit={save} className="flex flex-col gap-4">
          {/* قسم التحكم بحجم الخط داخل الإعدادات */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-bold text-muted-foreground">حجم الخط</span>
            <div className="flex items-center justify-between rounded-xl border border-border bg-background p-2">
              <span className="text-sm text-foreground">تعديل حجم خط المحادثة</span>
              <div className="flex items-center gap-1 overflow-hidden rounded-lg bg-secondary" role="group">
                <button
                  type="button"
                  onClick={() => onFontChange(-1)}
                  disabled={fontIndex === 0}
                  aria-label="تصغير الخط"
                  className="flex size-9 items-center justify-center text-muted-foreground transition active:scale-95 disabled:opacity-40"
                >
                  <AArrowDown className="size-4" aria-hidden />
                </button>
                <button
                  type="button"
                  onClick={() => onFontChange(1)}
                  disabled={fontIndex === maxFontIndexLength - 1}
                  aria-label="تكبير الخط"
                  className="flex size-9 items-center justify-center text-muted-foreground transition active:scale-95 disabled:opacity-40"
                >
                  <AArrowUp className="size-4" aria-hidden />
                </button>
              </div>
            </div>
          </div>

          <fieldset className="flex flex-col gap-3">
            <legend className="mb-2 text-xs font-bold text-muted-foreground">الأسماء</legend>
            <label className="flex flex-col gap-1.5 text-sm text-card-foreground">
              اسمي
              <input value={form.myName} onChange={update('myName')} maxLength={40} required className={inputClass} />
            </label>
            <label className="flex flex-col gap-1.5 text-sm text-card-foreground">
              اسم الطرف الآخر
              <input
                value={form.partnerName}
                onChange={update('partnerName')}
                maxLength={40}
                required
                className={inputClass}
              />
            </label>
          </fieldset>

          <fieldset className="flex flex-col gap-3">
            <legend className="mb-2 text-xs font-bold text-muted-foreground">
              تغيير كلمة السر (اتركها فارغة لعدم التغيير)
            </legend>
            <input
              type="password"
              value={form.currentPassword}
              onChange={update('currentPassword')}
              placeholder="كلمة السر الحالية"
              aria-label="كلمة السر الحالية"
              autoComplete="current-password"
              required={!!form.newPassword}
              className={inputClass}
            />
            <input
              type="password"
              value={form.newPassword}
              onChange={update('newPassword')}
              placeholder="كلمة السر الجديدة"
              aria-label="كلمة السر الجديدة"
              autoComplete="new-password"
              maxLength={128}
              className={inputClass}
            />
            <input
              type="password"
              value={form.confirm}
              onChange={update('confirm')}
              placeholder="تأكيد كلمة السر الجديدة"
              aria-label="تأكيد كلمة السر الجديدة"
              autoComplete="new-password"
              maxLength={128}
              required={!!form.newPassword}
              className={inputClass}
            />
          </fieldset>

          {message && (
            <p role="status" className={message.ok ? 'text-sm text-primary' : 'text-sm text-destructive'}>
              {message.text}
            </p>
          )}

          <button
            type="submit"
            disabled={saving}
            className="rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition active:scale-95 disabled:opacity-50"
          >
            {saving ? '...' : 'حفظ التغييرات'}
          </button>
        </form>

        <div className="mt-5 flex flex-col gap-2.5 border-t border-border pt-5">
          <NotifyButton />
          <button
            type="button"
            onClick={onWipe}
            className="flex w-full items-center justify-center gap-2 rounded-xl bg-destructive/15 py-3 text-sm font-bold text-destructive transition active:scale-95"
          >
            <Trash2 className="size-4" aria-hidden />
            حذف جميع الرسائل
          </button>
        </div>
      </div>
    </div>
  )
}
