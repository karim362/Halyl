'use client'

import { useCallback, useEffect, useState } from 'react'
import { mutate } from 'swr'
import { Calculator } from '@/components/calculator'
import { UnlockScreen } from '@/components/unlock-screen'
import { ChatScreen } from '@/components/chat-screen'

type View = 'calc' | 'unlock' | 'chat'

export function SecretApp() {
  const [view, setView] = useState<View>('calc')

  const lock = useCallback(() => {
    setView('calc')
    mutate('/api/messages', undefined, { revalidate: false })
    fetch('/api/lock', { method: 'POST', keepalive: true }).catch(() => {})
  }, [])

  useEffect(() => {
    fetch('/api/lock', { method: 'POST', keepalive: true }).catch(() => {})
  }, [])

  useEffect(() => {
    if (view === 'calc') return
    const onHide = () => {
      if (document.visibilityState === 'hidden') lock()
    }
    document.addEventListener('visibilitychange', onHide)
    window.addEventListener('pagehide', lock)
    return () => {
      document.removeEventListener('visibilitychange', onHide)
      window.removeEventListener('pagehide', lock)
    }
  }, [view, lock])

  if (view === 'unlock') return <UnlockScreen onUnlocked={() => setView('chat')} onCancel={() => setView('calc')} />
  if (view === 'chat') return <ChatScreen onLock={lock} />
  return <Calculator onSecret={() => setView('unlock')} />
}
