'use client'

import { useState } from 'react'
import useSWR from 'swr'
import { Lock } from 'lucide-react'

const fetcher = (url: string) => fetch(url, { cache: 'no-store' }).then((r) => r.json())

const ERRORS: Record<string, string> = {
  invalid: 'كلمة السر غير صحيحة',
  rate_limited: 'محاولات كثيرة. حاول بعد 15 دقيقة',
  names_required: 'أدخل الاسمين',
  password_length: 'كلمة السر يجب أن تكون 4 أحرف على الأقل',
  passwords_same: 'يجب أن تكون كلمتا السر مختلفتين',
  already_configured: 'تم الإعداد مسبقاً',
}

const inputClass =
  'w-full rounded-xl border border-border bg-background px-4 py-3 text-base text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none pointer-events-auto relative z-[100000] select-text touch-auto cursor-text'

export function UnlockScreen({ onUnlocked, onCancel }: { onUnlocked: () => void; onCancel: () => void }) {
  const { data, isLoading } = useSWR<{ configured: boolean }>('/api/setup', fetcher)
  const [error, setError] = useState('')
  const [pending, setPending] = useState(false)

  const submit = async (url: string, payload: Record<string, string>) => {
    setPending(true)
    setError('')
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const json = await res.json().catch(() => ({}))
      if (!res.ok) {
        setError(ERRORS[json.error] ?? 'حدث خطأ')
        return
      }
      onUnlocked()
    } finally {
      setPending(false)
    }
  }

  const onLogin = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    submit('/api/unlock', { password: String(fd.get('password') ?? '') })
  }

  const onSetup = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const fd = new FormData(e.currentTarget)
    submit('/api/setup', {
      myName: String(fd.get('myName') ?? ''),
      herName: String(fd.get('herName') ?? ''),
      myPassword: String(fd.get('myPassword') ?? ''),
      herPassword: String(fd.get('herPassword') ?? ''),
    })
  }

  // دالة لإيقاف أي منع للضغط قادم من الآلة الحاسبة
  const enableInputInteraction = (e: React.SyntheticEvent) => {
    e.stopPropagation()
  }

  return (
    <div className="fixed inset-0 z-[99999] flex h-dvh w-full items-center justify-center bg-background/95 backdrop-blur-md p-6 pointer-events-auto select-text">
      <div className="w-full max-w-xs space-y-5 relative z-[100000] pointer-events-auto">
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="flex size-12 items-center justify-center rounded-full bg-secondary">
            <Lock className="size-5 text-foreground" aria-hidden />
          </div>
          <h1 className="text-lg font-bold text-foreground">
            {data && !data.configured ? 'الإعداد لأول مرة' : 'أدخل كلمة السر'}
          </h1>
          {data && !data.configured && (
            <p className="text-pretty text-xs leading-relaxed text-muted-foreground">
              كل شخص له كلمة سر خاصة. كلمة السر تحدد من يكتب.
            </p>
          )}
        </div>

        {isLoading || !data ? (
          <div className="h-12 animate-pulse rounded-xl bg-secondary" />
        ) : data.configured ? (
          <form onSubmit={onLogin} className="space-y-3 pointer-events-auto">
            <input
              id="password"
              name="password"
              type="password"
              inputMode="numeric"
              autoComplete="off"
              autoFocus
              required
              className={inputClass}
              onMouseDownCapture={enableInputInteraction}
              onTouchStartCapture={enableInputInteraction}
              onClick={enableInputInteraction}
            />
            <button
              type="submit"
              disabled={pending}
              className="w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition active:scale-95 disabled:opacity-60 pointer-events-auto"
            >
              {pending ? '...' : 'فتح'}
            </button>
          </form>
        ) : (
          <form onSubmit={onSetup} className="space-y-3 pointer-events-auto">
            <fieldset className="space-y-2">
              <legend className="mb-1 text-xs font-semibold text-muted-foreground">أنت</legend>
              <input 
                name="myName" 
                placeholder="اسمك" 
                required 
                maxLength={40} 
                className={inputClass} 
                aria-label="اسمك" 
                onMouseDownCapture={enableInputInteraction}
                onTouchStartCapture={enableInputInteraction}
                onClick={enableInputInteraction}
              />
              <input 
                name="myPassword" 
                type="password" 
                inputMode="numeric" 
                placeholder="كلمة السر الخاصة بك" 
                required 
                minLength={4} 
                autoComplete="new-password" 
                className={inputClass} 
                aria-label="كلمة السر الخاصة بك" 
                onMouseDownCapture={enableInputInteraction}
                onTouchStartCapture={enableInputInteraction}
                onClick={enableInputInteraction}
              />
            </fieldset>
            <fieldset className="space-y-2">
              <legend className="mb-1 text-xs font-semibold text-muted-foreground">هي</legend>
              <input 
                name="herName" 
                placeholder="اسمها" 
                required 
                maxLength={40} 
                className={inputClass} 
                aria-label="اسمها" 
                onMouseDownCapture={enableInputInteraction}
                onTouchStartCapture={enableInputInteraction}
                onClick={enableInputInteraction}
              />
              <input 
                name="herPassword" 
                type="password" 
                inputMode="numeric" 
                placeholder="كلمة السر الخاصة بها" 
                required 
                minLength={4} 
                autoComplete="new-password" 
                className={inputClass} 
                aria-label="كلمة السر الخاصة بها" 
                onMouseDownCapture={enableInputInteraction}
                onTouchStartCapture={enableInputInteraction}
                onClick={enableInputInteraction}
              />
            </fieldset>
            <button
              type="submit"
              disabled={pending}
              className="w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground transition active:scale-95 disabled:opacity-60 pointer-events-auto"
            >
              {pending ? '...' : 'حفظ وفتح'}
            </button>
          </form>
        )}

        {error && (
          <p role="alert" className="text-center text-sm text-destructive">
            {error}
          </p>
        )}

        <button type="button" onClick={onCancel} className="w-full py-2 text-xs text-muted-foreground pointer-events-auto">
          رجوع
        </button>
      </div>
    </div>
  )
}
