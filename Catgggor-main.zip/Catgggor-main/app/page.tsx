import { SecretApp } from '@/components/secret-app'

export default function Page() {
  return <SecretApp />
}
