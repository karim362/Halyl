import { NextResponse } from 'next/server'
import { getSessionRole } from '@/lib/auth'
import { db } from '@/lib/db'
import { chatPushSubscriptions } from '@/lib/db/schema'
import { getVapidKeys } from '@/lib/push'

const unauthorized = () => NextResponse.json({ error: 'unauthorized' }, { status: 401 })

export async function GET() {
  const role = await getSessionRole()
  if (!role) return unauthorized()
  const { publicKey } = await getVapidKeys()
  return NextResponse.json({ publicKey }, { headers: { 'Cache-Control': 'no-store' } })
}

export async function POST(req: Request) {
  const role = await getSessionRole()
  if (!role) return unauthorized()

  const body = await req.json().catch(() => null)
  const endpoint = String(body?.endpoint ?? '')
  const p256dh = String(body?.keys?.p256dh ?? '')
  const auth = String(body?.keys?.auth ?? '')

  const valid =
    endpoint.startsWith('https://') && endpoint.length < 1000 && p256dh && p256dh.length < 200 && auth && auth.length < 100
  if (!valid) return NextResponse.json({ error: 'invalid' }, { status: 400 })

  await db
    .insert(chatPushSubscriptions)
    .values({ endpoint, role, p256dh, auth })
    .onConflictDoUpdate({ target: chatPushSubscriptions.endpoint, set: { role, p256dh, auth } })

  return NextResponse.json({ ok: true })
}
