import { NextResponse } from 'next/server'
import { sql } from 'drizzle-orm'
import { db } from '@/lib/db'
import { chatUsers } from '@/lib/db/schema'
import { createSession, hashPassword } from '@/lib/auth'

async function isConfigured() {
  const [row] = await db.select({ count: sql<number>`count(*)::int` }).from(chatUsers)
  return (row?.count ?? 0) > 0
}

export async function GET() {
  return NextResponse.json({ configured: await isConfigured() })
}

export async function POST(req: Request) {
  if (await isConfigured()) {
    return NextResponse.json({ error: 'already_configured' }, { status: 403 })
  }
  const body = await req.json().catch(() => null)
  const myName = String(body?.myName ?? '').trim().slice(0, 40)
  const herName = String(body?.herName ?? '').trim().slice(0, 40)
  const myPassword = String(body?.myPassword ?? '')
  const herPassword = String(body?.herPassword ?? '')

  if (!myName || !herName) return NextResponse.json({ error: 'names_required' }, { status: 400 })
  if (myPassword.length < 4 || herPassword.length < 4 || myPassword.length > 128 || herPassword.length > 128) {
    return NextResponse.json({ error: 'password_length' }, { status: 400 })
  }
  if (myPassword === herPassword) {
    return NextResponse.json({ error: 'passwords_same' }, { status: 400 })
  }

  await db
    .insert(chatUsers)
    .values([
      { role: 'me', name: myName, passwordHash: await hashPassword(myPassword) },
      { role: 'her', name: herName, passwordHash: await hashPassword(herPassword) },
    ])
    .onConflictDoNothing()

  await createSession('me')
  return NextResponse.json({ ok: true })
}
