import { NextResponse } from 'next/server'
import { asc } from 'drizzle-orm'
import { db } from '@/lib/db'
import { chatMessages, chatUsers } from '@/lib/db/schema'
import { getSessionRole } from '@/lib/auth'

const unauthorized = () => NextResponse.json({ error: 'unauthorized' }, { status: 401 })

export async function GET() {
  const role = await getSessionRole()
  if (!role) return unauthorized()

  const [messages, users] = await Promise.all([
    db.select().from(chatMessages).orderBy(asc(chatMessages.id)).limit(500),
    db.select({ role: chatUsers.role, name: chatUsers.name }).from(chatUsers),
  ])
  const partner = users.find((u) => u.role !== role)
  const self = users.find((u) => u.role === role)

  return NextResponse.json(
    {
      me: role,
      myName: self?.name ?? '',
      partnerName: partner?.name ?? '',
      messages: messages.map((m) => ({
        id: m.id,
        mine: m.sender === role,
        body: m.body,
        createdAt: m.createdAt,
      })),
    },
    { headers: { 'Cache-Control': 'no-store' } },
  )
}

export async function POST(req: Request) {
  const role = await getSessionRole()
  if (!role) return unauthorized()

  const body = await req.json().catch(() => null)
  const text = String(body?.body ?? '').trim()
  if (!text || text.length > 2000) {
    return NextResponse.json({ error: 'invalid' }, { status: 400 })
  }
  await db.insert(chatMessages).values({ sender: role, body: text })
  return NextResponse.json({ ok: true })
}

export async function DELETE() {
  const role = await getSessionRole()
  if (!role) return unauthorized()
  await db.delete(chatMessages)
  return NextResponse.json({ ok: true })
}
