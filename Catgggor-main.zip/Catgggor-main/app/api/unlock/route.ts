import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { chatUsers } from '@/lib/db/schema'
import {
  clearAttempts,
  createSession,
  isRateLimited,
  recordFailedAttempt,
  verifyPassword,
  type Role,
} from '@/lib/auth'

export async function POST(req: Request) {
  if (await isRateLimited()) {
    return NextResponse.json({ error: 'rate_limited' }, { status: 429 })
  }
  const body = await req.json().catch(() => null)
  const password = String(body?.password ?? '')
  if (!password || password.length > 128) {
    await recordFailedAttempt()
    return NextResponse.json({ error: 'invalid' }, { status: 401 })
  }

  const users = await db.select().from(chatUsers)
  let matched: Role | null = null
  for (const user of users) {
    if (await verifyPassword(password, user.passwordHash)) matched = user.role as Role
  }

  if (!matched) {
    await recordFailedAttempt()
    return NextResponse.json({ error: 'invalid' }, { status: 401 })
  }

  await clearAttempts()
  await createSession(matched)
  return NextResponse.json({ ok: true })
}
