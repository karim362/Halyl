import { NextResponse } from 'next/server'
import { eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { chatUsers } from '@/lib/db/schema'
import { getSessionRole, hashPassword, verifyPassword } from '@/lib/auth'

const fail = (error: string, status = 400) => NextResponse.json({ error }, { status })

export async function PATCH(req: Request) {
  const role = await getSessionRole()
  if (!role) return fail('unauthorized', 401)
  const partnerRole = role === 'me' ? 'her' : 'me'

  const body = await req.json().catch(() => null)
  const myName = String(body?.myName ?? '').trim().slice(0, 40)
  const partnerName = String(body?.partnerName ?? '').trim().slice(0, 40)
  const currentPassword = String(body?.currentPassword ?? '')
  const newPassword = String(body?.newPassword ?? '')

  if (!myName || !partnerName) return fail('names_required')

  const users = await db.select().from(chatUsers)
  const mine = users.find((u) => u.role === role)
  const partner = users.find((u) => u.role === partnerRole)
  if (!mine || !partner) return fail('not_configured')

  let passwordHash: string | undefined
  if (newPassword) {
    if (newPassword.length < 4 || newPassword.length > 128) return fail('password_length')
    if (!(await verifyPassword(currentPassword, mine.passwordHash))) return fail('wrong_password', 403)
    if (await verifyPassword(newPassword, partner.passwordHash)) return fail('passwords_same')
    passwordHash = await hashPassword(newPassword)
  }

  await db
    .update(chatUsers)
    .set(passwordHash ? { name: myName, passwordHash } : { name: myName })
    .where(eq(chatUsers.role, role))
  await db.update(chatUsers).set({ name: partnerName }).where(eq(chatUsers.role, partnerRole))

  return NextResponse.json({ ok: true })
}
