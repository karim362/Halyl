import { NextResponse } from 'next/server'
import { eq } from 'drizzle-orm'
import { db } from '@/lib/db'
import { chatUsers } from '@/lib/db/schema'
import { getSessionRole } from '@/lib/auth'
import { claimSignalSlot, sendPushToRole } from '@/lib/push'

export async function POST() {
  const role = await getSessionRole()
  if (!role) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })

  if (!(await claimSignalSlot(role))) {
    return NextResponse.json({ status: 'cooldown' })
  }

  const [sender] = await db.select({ name: chatUsers.name }).from(chatUsers).where(eq(chatUsers.role, role))
  const delivered = await sendPushToRole(role === 'me' ? 'her' : 'me', {
    title: 'تذكير',
    body: `${sender?.name || 'حدا'} بدو يحكي معك`,
  })

  return NextResponse.json({ status: delivered > 0 ? 'sent' : 'no_devices' })
}
