type Token = { type: 'num'; value: number } | { type: 'op'; value: string }

const PRECEDENCE: Record<string, number> = { '+': 1, '-': 1, '*': 2, '/': 2 }

function tokenize(expr: string): Token[] {
  const tokens: Token[] = []
  let i = 0
  while (i < expr.length) {
    const ch = expr[i]
    const prev = tokens[tokens.length - 1]
    const isUnaryMinus = ch === '-' && (!prev || prev.type === 'op')
    if (/[0-9.]/.test(ch) || isUnaryMinus) {
      let j = i + 1
      while (j < expr.length && /[0-9.]/.test(expr[j])) j++
      const raw = expr.slice(i, j)
      if (raw === '-' || (raw.match(/\./g)?.length ?? 0) > 1) throw new Error('bad number')
      let value = Number(raw)
      if (expr[j] === '%') {
        value /= 100
        j++
      }
      tokens.push({ type: 'num', value })
      i = j
    } else if (ch in PRECEDENCE) {
      if (!prev || prev.type === 'op') throw new Error('bad op')
      tokens.push({ type: 'op', value: ch })
      i++
    } else {
      throw new Error('bad char')
    }
  }
  if (!tokens.length || tokens[tokens.length - 1].type === 'op') throw new Error('incomplete')
  return tokens
}

export function evaluate(expr: string): number {
  const tokens = tokenize(expr)
  const output: number[] = []
  const ops: string[] = []
  const apply = () => {
    const op = ops.pop()!
    const b = output.pop()!
    const a = output.pop()!
    output.push(op === '+' ? a + b : op === '-' ? a - b : op === '*' ? a * b : a / b)
  }
  for (const t of tokens) {
    if (t.type === 'num') output.push(t.value)
    else {
      while (ops.length && PRECEDENCE[ops[ops.length - 1]] >= PRECEDENCE[t.value]) apply()
      ops.push(t.value)
    }
  }
  while (ops.length) apply()
  return output[0]
}

export function formatResult(n: number) {
  if (!Number.isFinite(n)) return 'Error'
  return String(Number.parseFloat(n.toPrecision(12)))
}

export const SECRET_EXPRESSION = '1/1'
