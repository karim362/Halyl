import { pgTable, serial, text, timestamp, integer } from 'drizzle-orm/pg-core'

export const chatUsers = pgTable('chat_users', {
  role: text('role').primaryKey(),
  name: text('name').notNull(),
  passwordHash: text('password_hash').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const chatSessions = pgTable('chat_sessions', {
  tokenHash: text('token_hash').primaryKey(),
  role: text('role').notNull(),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const chatMessages = pgTable('chat_messages', {
  id: serial('id').primaryKey(),
  sender: text('sender').notNull(),
  body: text('body').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

// جدول جديد ومستقل تماماً لإيصالات القراءة
export const chatReadReceipts = pgTable('chat_read_receipts', {
  id: serial('id').primaryKey(),
  messageId: integer('message_id').notNull(),
  readerRole: text('reader_role').notNull(),
  readAt: timestamp('read_at', { withTimezone: true }).notNull().defaultNow(),
})

export const chatPushSubscriptions = pgTable('chat_push_subscriptions', {
  endpoint: text('endpoint').primaryKey(),
  role: text('role').notNull(),
  p256dh: text('p256dh').notNull(),
  auth: text('auth').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const chatConfig = pgTable('chat_config', {
  key: text('key').primaryKey(),
  value: text('value').notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
})

export const chatLoginAttempts = pgTable('chat_login_attempts', {
  id: serial('id').primaryKey(),
  ip: text('ip').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})
