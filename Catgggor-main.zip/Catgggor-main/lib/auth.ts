import 'server-only'
import { createHash, randomBytes, scrypt as scryptCb, timingSafeEqual } from 'node:crypto'
import { promisify } from 'node:util'
import { cookies, headers } from 'next/headers'
import { and, eq, gt, lt, sql } from 'drizzle-orm'
import { db } from '@/lib/db'
import { chatLoginAttempts, chatSessions } from '@/lib/db/schema'

const scrypt = promisify(scryptCb) as (pw: string, salt: Buffer, len: number) => Promise<Buffer>

export type Role = 'me' | 'her'
export const SESSION_COOKIE = 'calc_sid'
const SESSION_TTL_MS = 1000 * 60 * 60 * 6
const MAX_ATTEMPTS = 5
const ATTEMPT_WINDOW_MS = 1000 * 60 * 15

export async function hashPassword(password: string) {
  const salt = randomBytes(16)
  const key = await scrypt(password, salt, 64)
  return `${salt.toString('hex')}:${key.toString('hex')}`
}

export async function verifyPassword(password: string, stored: string) {
  const [saltHex, keyHex] = stored.split(':')
  if (!saltHex || !keyHex) return false
  const expected = Buffer.from(keyHex, 'hex')
  const actual = await scrypt(password, Buffer.from(saltHex, 'hex'), expected.length)
  return timingSafeEqual(expected, actual)
}

const sha256 = (value: string) => createHash('sha256').update(value).digest('hex')

export async function createSession(role: Role) {
  const token = randomBytes(32).toString('base64url')
  await db.delete(chatSessions).where(lt(chatSessions.expiresAt, new Date()))
  await db.insert(chatSessions).values({
    tokenHash: sha256(token),
    role,
    expiresAt: new Date(Date.now() + SESSION_TTL_MS),
  })
  const jar = await cookies()
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: true,
    sameSite: process.env.NODE_ENV === 'development' ? 'none' : 'strict',
    path: '/',
  })
}

export async function getSessionRole(): Promise<Role | null> {
  const token = (await cookies()).get(SESSION_COOKIE)?.value
  if (!token) return null
  const [row] = await db
    .select({ role: chatSessions.role })
    .from(chatSessions)
    .where(and(eq(chatSessions.tokenHash, sha256(token)), gt(chatSessions.expiresAt, new Date())))
    .limit(1)
  return (row?.role as Role) ?? null
}

export async function destroySession() {
  const jar = await cookies()
  const token = jar.get(SESSION_COOKIE)?.value
  if (token) await db.delete(chatSessions).where(eq(chatSessions.tokenHash, sha256(token)))
  jar.delete(SESSION_COOKIE)
}

async function clientIp() {
  const h = await headers()
  return h.get('x-forwarded-for')?.split(',')[0]?.trim() || h.get('x-real-ip') || 'unknown'
}

export async function isRateLimited() {
  const ip = await clientIp()
  const since = new Date(Date.now() - ATTEMPT_WINDOW_MS)
  const [row] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(chatLoginAttempts)
    .where(and(eq(chatLoginAttempts.ip, ip), gt(chatLoginAttempts.createdAt, since)))
  return (row?.count ?? 0) >= MAX_ATTEMPTS
}

export async function recordFailedAttempt() {
  const ip = await clientIp()
  await db.delete(chatLoginAttempts).where(lt(chatLoginAttempts.createdAt, new Date(Date.now() - ATTEMPT_WINDOW_MS)))
  await db.insert(chatLoginAttempts).values({ ip })
}

export async function clearAttempts() {
  const ip = await clientIp()
  await db.delete(chatLoginAttempts).where(eq(chatLoginAttempts.ip, ip))
}
