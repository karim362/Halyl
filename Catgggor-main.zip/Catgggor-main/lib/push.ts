import 'server-only'
import webPush from 'web-push'
import { eq, inArray, sql } from 'drizzle-orm'
import { db } from '@/lib/db'
import { chatConfig, chatPushSubscriptions } from '@/lib/db/schema'
import type { Role } from '@/lib/auth'

const VAPID_KEY = 'vapid_keys'
const SIGNAL_KEY = 'last_signal'
export const SIGNAL_COOLDOWN_SECONDS = 30

type VapidKeys = { publicKey: string; privateKey: string }

let cachedKeys: VapidKeys | null = null

export async function getVapidKeys(): Promise<VapidKeys> {
  if (cachedKeys) return cachedKeys
  const generated = webPush.generateVAPIDKeys()
  await db
    .insert(chatConfig)
    .values({ key: VAPID_KEY, value: JSON.stringify(generated) })
    .onConflictDoNothing()
  const [row] = await db.select({ value: chatConfig.value }).from(chatConfig).where(eq(chatConfig.key, VAPID_KEY))
  cachedKeys = JSON.parse(row.value) as VapidKeys
  return cachedKeys
}

export async function claimSignalSlot(sender: Role) {
  const rows = await db
    .insert(chatConfig)
    .values({ key: `${SIGNAL_KEY}_${sender}`, value: '1' })
    .onConflictDoUpdate({
      target: chatConfig.key,
      set: { updatedAt: sql`now()` },
      setWhere: sql`${chatConfig.updatedAt} < now() - make_interval(secs => ${SIGNAL_COOLDOWN_SECONDS})`,
    })
    .returning({ key: chatConfig.key })
  return rows.length > 0
}

export async function sendPushToRole(role: Role, payload: { title: string; body: string }) {
  const keys = await getVapidKeys()
  const subs = await db.select().from(chatPushSubscriptions).where(eq(chatPushSubscriptions.role, role))
  const expired: string[] = []

  await Promise.all(
    subs.map(async (s) => {
      try {
        await webPush.sendNotification(
          { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
          JSON.stringify(payload),
          {
            vapidDetails: { subject: 'mailto:noreply@example.com', ...keys },
            TTL: 60 * 60,
            urgency: 'high',
          },
        )
      } catch (err) {
        const status = (err as { statusCode?: number }).statusCode
        if (status === 404 || status === 410) expired.push(s.endpoint)
      }
    }),
  )

  if (expired.length) {
    await db.delete(chatPushSubscriptions).where(inArray(chatPushSubscriptions.endpoint, expired))
  }
  return subs.length - expired.length
}
